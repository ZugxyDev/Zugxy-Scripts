--PHILIP'S FILER       ALLE RETTIGHEDER      KAN KØBES HER: https://discord.gg/cWyYnB2nAB
local open = false
local delay = 200
local kort = 0

--[[ ////////////////////////////////////////// ]]

RegisterNetEvent('vrp_kort:showvcard')
AddEventHandler('vrp_kort:showvcard', function(identity)
    open = true
    v = kort+1
    SendNUIMessage({
      type = "cardvdata",
      status = true,
      fornavn = identity.firstname,
      efternavn = identity.name,
      tlfnummer = identity.phone,
      vkort = v
    })
    local data = v
    TriggerEvent("test", data)
end)

RegisterNetEvent('vrp_kort:showvcardcustom')
AddEventHandler('vrp_kort:showvcardcustom', function(url)
    open = true
    v = kort+1
    SendNUIMessage({
      type = "cardvcustomdata",
      status = true,
      url = url,
      vkort = v
    })
    local data = v
    TriggerEvent("test", data)
end)

RegisterNetEvent('vrp_kort:showkcard')
AddEventHandler('vrp_kort:showkcard', function(identity)
    open = true
    d = kort+1
    SendNUIMessage({
      type = "cardkdata",
      status = true,
      fornavn = identity.firstname,
      efternavn = identity.name,
      tlfnummer = identity.phone,
      cprnummer = identity.registration,
      alder = identity.age,
      dkort = d
    })
    local data = d
    TriggerEvent("test", data)
end)

RegisterNetEvent('vrp_kort:showscard')
AddEventHandler('vrp_kort:showscard', function(identity)
    open = true
    s = kort+1
    SendNUIMessage({
      type = "cardsdata",
      status = true,
      fornavn = identity.firstname,
      efternavn = identity.name,
      cprnummer = identity.registration,
      alder = identity.age,
      home = identity.hjem,
      city = Config.by,
      postalcode = Config.postnr,
      skort = s
    })
    local data = s
    TriggerEvent("test", data)
end)

RegisterNetEvent("test")
AddEventHandler("test", function(data)
    kort = data
end)

--[[ ////////////////////////////////////////// ]]
Citizen.CreateThread(function()
        while true do
                Citizen.Wait(0)
        if IsControlJustReleased(1, 57) and open then
            open = false
            kort = 0
            TriggerServerEvent("reset:local")
                        SendNUIMessage({
                status = false,
                        })
                end
        end
end)
--[[ ////////////////////////////////////////// ]]

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(delay)
        while open do
            delay = 0
            Citizen.Wait(delay)
            drawTxt('Tryk ~r~[F10]~s~ for at lukke kort visning', 4, 1, 0.5, 0.40, 0.6, 255, 255, 255, 255)
        end
        delay = 200
    end
end)


function drawTxt(text, font, centre, x, y, scale, r, g, b, a)
        SetTextFont(font)
        SetTextProportional(0)
        SetTextScale(scale, scale)
        SetTextColour(r, g, b, a)
        SetTextDropShadow(0, 0, 0, 0, 255)
        SetTextEdge(1, 0, 0, 0, 255)
        SetTextDropShadow()
        SetTextOutline()
        SetTextCentre(centre)
        SetTextEntry("STRING")
        AddTextComponentString(text)
        DrawText(x, y)
end

--[[ ////////////////////////////////////////// ]]

RegisterNetEvent("pil:visitkortse")
AddEventHandler("pil:visitkortse", function()
    TriggerServerEvent("pil:visitkort")
end)

RegisterNetEvent("pil:visitkortvis")
AddEventHandler("pil:visitkortvis", function()
    TriggerServerEvent("pil:visitkort")
end)

RegisterNetEvent("pil:kørekortse")
AddEventHandler("pil:kørekortse", function()
    TriggerServerEvent("pil:kørekort")
end)

RegisterNetEvent("pil:kørekortvis")
AddEventHandler("pil:kørekortvis", function()
    TriggerServerEvent("pil:kørekort")
end)

RegisterNetEvent("pil:sundhedskortse")
AddEventHandler("pil:sundhedskortse", function()
    TriggerServerEvent("pil:sundhedskort")
end)

RegisterNetEvent("pil:sundhedskortvis")
AddEventHandler("pil:sundhedskortvis", function()
    TriggerServerEvent("pil:sundhedskort")
end)

--[[ ////////////////////////////////////////// ]]

-- WHEN YOU RESTART THEN THE NUI NOT FREEZ
AddEventHandler("onResourceStop",function(a)if a==GetCurrentResourceName()then SetNuiFocus(false,false) end end)