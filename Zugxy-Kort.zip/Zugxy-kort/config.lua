Config = {}

-- SUNDHEDSKORT

Config.by = "StateRP" -- Byen på sundhedskort

Config.postnr = "2022" -- Post nummer på sundhedskort

------------------------------------------

-- HAR IKKE KØREKORT
Config.harikke = 0 -- Skal være et tal, i de fleste tilfælde efter hvad køreskole du bruger er det 0 eller 1.

-- HAR FÅET FRATAGET KREKORT
Config.frataget = 2 -- Skal være et tal, i de fleste tilfælde efter hvad køreskole du bruger er det 1 eller 2.

-- HAR KØREKORT
Config.har = 3-- Skal være et tal, i de fleste tilfælde efter hvad køreskole du bruger er det 1 eller 3.