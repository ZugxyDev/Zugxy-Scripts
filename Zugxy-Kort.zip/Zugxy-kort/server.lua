local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")
MySQL2 = module("vrp_mysql", "MySQL")

vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP","vrp_kort")
-------------------------------------------------------------
--                         LOCAL                           --
-------------------------------------------------------------

local sevisitkort = false
local sekorekort = false
local sesundhedskort = false

RegisterServerEvent("reset:local")
AddEventHandler("reset:local", function()
  sevisitkort = false
  sekorekort = false
  sesundhedskort = false
end)

-------------------------------------------------------------
--                         MySQL                           --
-------------------------------------------------------------
MySQL2.createCommand("vRP/vrpkort_tables", [[
CREATE TABLE IF NOT EXISTS vrp_kort(
  user_id INTEGER,
  visitkorturl VARCHAR(100)
);
]])

MySQL2.execute("vRP/vrpkort_tables")

-------------------------------------------------------------
--                     VISITKORT                           --
-------------------------------------------------------------
RegisterServerEvent("pil:visitkort")
AddEventHandler("pil:visitkort", function()
    local source = source
    local user_id = vRP.getUserId({source})
    vRP.getUserIdentity({user_id, function(identity)
        if identity then
            local alldata = {firstname = identity.firstname,name = identity.name,phone = identity.phone}
            vRPclient.getNearestPlayer(source,{3},function(nplayer)
            MySQL.Async.fetchAll("SELECT visitkorturl FROM vrp_kort WHERE user_id = @user_id", {
              ["@user_id"] = user_id
            }, function(customv, affected)
            if customv[1] ~= nil then
              local url = customv[1].visitkorturl
              if sevisitkort then
                TriggerClientEvent('vrp_kort:showvcardcustom', source, url)
              elseif nplayer ~= nil then
                TriggerClientEvent('vrp_kort:showvcardcustom', source, url)
                TriggerClientEvent("pNotify:SendNotification", source,{text = "Du viste dit visitkort.", type = "success", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
              else
                TriggerClientEvent("pNotify:SendNotification", source,{text = "Der er ingen tæt på dig dig.", type = "error", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
              end
            else
              if sevisitkort then
                TriggerClientEvent('vrp_kort:showvcard', source, alldata)
              elseif nplayer ~= nil then
                TriggerClientEvent('vrp_kort:showvcard', nplayer, alldata)
                TriggerClientEvent("pNotify:SendNotification", source,{text = "Du viste dit visitkort.", type = "success", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
              else
                TriggerClientEvent("pNotify:SendNotification", source,{text = "Der er ingen tæt på dig dig.", type = "error", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
              end
            end
            end)
          end)
        end
    end})
end)

-------------------------------------------------------------
--                      K├śREKORT                           --
------------------------------------------------------------
RegisterServerEvent("pil:kørekort")
AddEventHandler("pil:kørekort", function()
  local source = source
  local user_id = vRP.getUserId({source})
  local player = vRP.getUserSource({user_id})
  local driverlicense = ""
  MySQL.Async.fetchAll("SELECT DmvTest FROM vrp_users WHERE id = @user_id", {
    ["@user_id"] = user_id
  }, function(driverlicense, affected)
    driverlicense = driverlicense[1].DmvTest

    if driverlicense == Config.harikke then
      TriggerClientEvent("pNotify:SendNotification", source,{text = "Du har ikke et kørekort.", type = "error", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
    elseif driverlicense == Config.frataget then
      TriggerClientEvent("pNotify:SendNotification", source,{text = "Dit kørekort er blevet frataget og kan derfor ikke vises.", type = "error", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
    elseif driverlicense == Config.har then
      vRP.getUserIdentity({user_id, function(identity)
        if identity then
          local alldata = {firstname = identity.firstname,name = identity.name,phone = identity.phone,registration = identity.registration,age = identity.age}
          vRPclient.getNearestPlayer(source,{5},function(nplayer)
              if sekorekort then
                sekorekort = false
                TriggerClientEvent('vrp_kort:showkcard', source, alldata)
              elseif nplayer ~= nil then
                TriggerClientEvent('vrp_kort:showkcard', nplayer, alldata)
              else
                TriggerClientEvent("pNotify:SendNotification", source,{text = "Der er ingen tæt på dig dig.", type = "error", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
              end
            end)
          end
        end})
      end
    end)
end)

-------------------------------------------------------------
--                      SUNDHEDSKORT                       --
-------------------------------------------------------------

RegisterServerEvent("pil:sundhedskort")
AddEventHandler("pil:sundhedskort", function()
    local source = source
    local user_id = vRP.getUserId({source})
    vRP.getUserIdentity({user_id, function(identity)
        if identity then
          vRP.getUserAddress({user_id, function(address)
            if address then
                home = address.home .." " .. address.number
            else
                home = "Hjemløs"
            end
            local alldata = {firstname = identity.firstname,name = identity.name,registration = identity.registration,age = identity.age, hjem = home}
            vRPclient.getNearestPlayer(source,{3},function(nplayer)
                if sesundhedskort then
                    TriggerClientEvent('vrp_kort:showscard', source, alldata)
                elseif nplayer ~= nil then
                    TriggerClientEvent('vrp_kort:showscard', nplayer, alldata)
                    TriggerClientEvent("pNotify:SendNotification", source,{text = "Du viste dit sundhedskort.", type = "success", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
                else
                    TriggerClientEvent("pNotify:SendNotification", source,{text = "Der er ingen tæt på dig dig.", type = "error", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
                end
              end)
            end})
          end
        end})
end)

-------------------------------------------------------------
--                         MENU                            --
-------------------------------------------------------------

local function ch_nulstilvisitkort(player,choice)
  local user_id = vRP.getUserId({player})
  MySQL.Async.execute("DELETE * FROM vrp_kort WHERE user_id = @user_id", {
    ["@user_id"] = user_id
  })
  TriggerClientEvent("pNotify:SendNotification", source,{text = "Du fjernet dit visitkort.", type = "success", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
end

local function ch_changevisitkort(player,choice)
  local user_id = vRP.getUserId({player})
  vRP.prompt({player, "Imgur link:", "", function(player,link)
    if link ~= nil then
      local url = link
      MySQL.Async.fetchAll("SELECT visitkorturl FROM vrp_kort WHERE user_id = @user_id", {
        ["@user_id"] = user_id
      }, function(visitkort, affected)
        if visitkort[1] ~= nil then
          MySQL.Async.execute("UPDATE vrp_kort SET visitkorturl = @update WHERE user_id = @user_id", {
            ["@user_id"] = user_id,
            ["@update"] = url
          })
          TriggerClientEvent('mythic_notify:client:SendAlert', player, { type = 'success', text = 'Du indsatte et custom visitkort.'}, 5000)
        else
          MySQL.Async.execute("INSERT INTO vrp_kort (user_id,visitkorturl) VALUES(@user_id,@update)", {
            ["@user_id"] = user_id,
            ["@update"] = url
          })
          TriggerClientEvent('mythic_notify:client:SendAlert', player, { type = 'success', text = 'Du indsatte et custom visitkort.'}, 5000)
        end
      end)
    else
      TriggerClientEvent('mythic_notify:client:SendAlert', player, { type = 'error', text = 'Du skal skrive noget i feltet.'}, 5000)
    end
  end})
end

local function ch_visitkortvis(player,choice)
  TriggerClientEvent("pil:visitkortvis", player)
end

local function ch_visitkortse(player,choice)
    TriggerClientEvent("pil:visitkortse", player)
    sevisitkort = true
end

local function ch_korekortvis(player,choice)
  TriggerClientEvent("pil:kørekortvis", player)
end

local function ch_korekortse(player,choice)
  TriggerClientEvent("pil:kørekortse", player)
  sekorekort = true
end

local function ch_sundhedskortvis(player,choice)
  TriggerClientEvent("pil:sundhedskortvis", player)
end

local function ch_sundhedskortse(player,choice)
  TriggerClientEvent("pil:sundhedskortse", player)
  sesundhedskort = true
end

local function ch_visitkortask(player,choice)
  local user_id = vRP.getUserId({player})
  vRPclient.getNearestPlayer(player,{3},function(nplayer)
    if nplayer ~= nil then
      vRP.request({nplayer,"ID: "..user_id.." - Anmoder om at se dit visitkort", 30, function(nplayer,ok)
        if ok then
          MySQL.Async.fetchAll("SELECT visitkorturl FROM vrp_kort WHERE user_id = @user_id", {
            ["@user_id"] = user_id
          }, function(customv, affected)
          if customv[1] ~= nil then
            local url = customv[1].visitkorturl
            TriggerClientEvent('vrp_kort:showvcardcustom', player, url)
            TriggerClientEvent("pNotify:SendNotification", nplayer,{text = "Du viste dit visitkort.", type = "success", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
          else
            vRP.getUserIdentity({nplayer, function(identity)
              if identity then
                local alldata = {firstname = identity.firstname,name = identity.name,phone = identity.phone}
                TriggerClientEvent('vrp_kort:showvcard', player, alldata)
              end
            end})
            TriggerClientEvent("pNotify:SendNotification", nplayer,{text = "Du viste dit visitkort.", type = "success", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
          end
          end)
        else
          TriggerClientEvent("pNotify:SendNotification", player,{text = "Spilleren vil ikke vise sit visitkort.", type = "error", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
        end
      end})
    else
      TriggerClientEvent("pNotify:SendNotification", player,{text = "Der er ingen tæt på dig dig.", type = "error", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
    end
  end)
end

local function ch_korekortask(player,choice)
  local user_id = vRP.getUserId({player})
  vRPclient.getNearestPlayer(player,{3},function(nplayer)
    if nplayer ~= nil then
      vRP.request({nplayer,"ID: "..user_id.." - Anmoder om at se dit kørekort", 30, function(nplayer,ok)
        if ok then
          MySQL.Async.fetchAll("SELECT DmvTest FROM vrp_users WHERE id = @user_id", {
            ["@user_id"] = nplayer
          }, function(driverlicense, affected)
            driverlicense = driverlicense[1].DmvTest

            if driverlicense == Config.harikke then
              TriggerClientEvent("pNotify:SendNotification", player,{text = "Spilleren har ikke kørekort.", type = "error", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
            elseif driverlicense == Config.frataget then
              TriggerClientEvent("pNotify:SendNotification", player,{text = "Spillerens kørekort er blevet frataget og kan derfor ikke vises.", type = "error", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
            elseif driverlicense == Config.har then
              vRP.getUserIdentity({user_id, function(identity)
                if identity then
                  local alldata = {firstname = identity.firstname,name = identity.name,phone = identity.phone,registration = identity.registration,age = identity.age}
                  TriggerClientEvent('vrp_kort:showkcard', player, alldata)
                  TriggerClientEvent("pNotify:SendNotification", nplayer,{text = "Du viste dit kørekort.", type = "success", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
                end
              end})
            end
          end)
        else
          TriggerClientEvent("pNotify:SendNotification", player,{text = "Spilleren vil ikke vise sit kørekort.", type = "error", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
        end
      end})
    else
      TriggerClientEvent("pNotify:SendNotification", player,{text = "Der er ingen tæt på dig dig.", type = "error", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
    end
  end)
end

local function ch_sundhedskortask(player,choice)
  local user_id = vRP.getUserId({player})
  vRPclient.getNearestPlayer(player,{3},function(nplayer)
    if nplayer ~= nil then
      vRP.request({nplayer,"ID: "..user_id.." - Anmoder om at se dit sundhedskort", 30, function(nplayer,ok)
        if ok then
          vRP.getUserIdentity({nplayer, function(identity)
            if identity then
              vRP.getUserAddress({nplayer, function(address)
                if address then
                    home = address.home .." " .. address.number
                else
                    home = "Hjemløs"
                end
                local alldata = {firstname = identity.firstname,name = identity.name,registration = identity.registration,age = identity.age, hjem = home}
                TriggerClientEvent('vrp_kort:showscard', player, alldata)
              end})
            end
          end})
        else
          TriggerClientEvent("pNotify:SendNotification", player,{text = "Spilleren vil ikke vise sit sundhedskort.", type = "error", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
        end
      end})
    else
      TriggerClientEvent("pNotify:SendNotification", player,{text = "Der er ingen tæt på dig dig.", type = "error", queue = "global", timeout = 5000, layout = "centerRight",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
    end
  end)
end

vRP.registerMenuBuilder({"main", function(add, data)
  local user_id = vRP.getUserId({data.player})
  if user_id ~= nil then
    local choices = {}

    -- build admin menu
    choices["Mine Kort"] = {function(player,choice)
      vRP.buildMenu({"mine kort", {player = player}, function(menu)
        menu.name = "Mine Kort"
        menu.css={top="75px",header_color="rgba(0,80,177)"}
        menu.onclose = function(player) vRP.openMainMenu({player}) end -- nest menu

        -- Visit funktioner

          menu["> Nulstil visitkort"] = {ch_nulstilvisitkort,"Nulstil visitkort."}
          menu["> Indsæt visitkort"] = {ch_changevisitkort,"Skift visitkort med url."}

        -- Se

          menu["Se Visitkort"] = {ch_visitkortse,"Se dit visitkort."}
          menu["Se Kørekort"] = {ch_korekortse,"Se dit kørekort."}
          menu["Se Sundhedskort"] = {ch_sundhedskortse,"Se dit sundhedskort."}

        -- Vis

          menu["Vis Visitkort"] = {ch_visitkortvis,"Vis dit visitkort til spiller."}
          menu["Vis Sundhedskort"] = {ch_sundhedskortvis,"Vis dit sundhedskort til spiller."}
          menu["Vis Kørekort"] = {ch_korekortvis,"Vis dit Kørekort til spiller."}

        vRP.openMenu({player,menu})
      end})
    end}

    add(choices)
  end
end})