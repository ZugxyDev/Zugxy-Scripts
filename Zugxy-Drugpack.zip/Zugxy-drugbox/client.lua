--PHILIP'S FILER       ALLE RETTIGHEDER      KAN KØBES HER: https://discord.gg/cWyYnB2nAB 
vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP","SCRIPTNAVNHER")

local spawn = false
local show = false
local blacklistedWeapon = false
local xcoord = nil
local ycoord = nil
local zcoord = nil
local spawnped = nil
local igang = false
local levering = false

function openGui()
  if show == false then
    show = true
    SetNuiFocus(true, true)

    SendNUIMessage(
      {
        show = true
      }
    )
  end
end

function closeGui()
  show = false
  SetNuiFocus(false)
  SendNUIMessage({show = false})
end

-- RegisterCommand('gui1', function(source)
--   openGui()
-- end)

RegisterNetEvent("bmz_drugbox:openGui")
AddEventHandler("bmz_drugbox:openGui", function(user_id)
	user_id = user_id
    openGui()
end)

RegisterNUICallback("button1", function()
  local player = GetPlayerPed(-1)
  if spawn == true then
    TriggerServerEvent("bmz_drugbox:button1")
  end
end)

RegisterNUICallback("button2", function()
  local player = GetPlayerPed(-1)
  if spawn == true then
    TriggerServerEvent("bmz_drugbox:button2")
  end
end)

RegisterNUICallback("button3", function()
  local player = GetPlayerPed(-1)
  if spawn == true then
    TriggerServerEvent("bmz_drugbox:button3")
  end
end)

RegisterNUICallback("button4", function()
  local player = GetPlayerPed(-1)
  if spawn == true then
    TriggerServerEvent("bmz_drugbox:button4")
  end
end)

RegisterNUICallback("close", function(data)
  closeGui()
end)

AddEventHandler("onResourceStop", function(resource)
  if resource == GetCurrentResourceName() then
    closeGui()
  end
end)

Citizen.CreateThread(function()
  while true do
      Citizen.Wait(math.random(7200000, 18200000))
      spawn = true
      TriggerEvent("randomsted")
  end
end)

RegisterNetEvent("randomsted")
AddEventHandler("randomsted", function()
  random = math.random(1,#cfg.steder)
  sted = cfg.steder[random]
  if spawn == true and igang == false then
    xcoord = sted.xyz.x
    ycoord = sted.xyz.y
    zcoord = sted.xyz.z
    TriggerServerEvent("bmz_updateS:coords", sted.xyz.x, sted.xyz.y, sted.xyz.z)
    TriggerServerEvent("bmz_drugbox:sendtwitter", random)
    Stykke = CreateObject(-1184096195,sted.xyz.x,sted.xyz.y,sted.xyz.z,true,false,false)
    Citizen.Wait(1000)
    Stykke3 = CreateObject(363555755,sted.xyz.x,sted.xyz.y,sted.xyz.z+0.85,true,false,false)
  end
end)

RegisterNetEvent("bmz_updateC:coords")
AddEventHandler("bmz_updateC:coords", function(x,y,z) 
  xcoord = x
  ycoord = y
  zcoord = z
  igang = true
  spawn = true
end)

RegisterCommand('sadas2zzza1', function(source)
  spawn = true
  TriggerEvent("bmz_accept:npc")
  TriggerServerEvent("spawntrue")
end)

RegisterNetEvent("bmz:spawntrue")
AddEventHandler("bmz:spawntrue", function()
    TriggerEvent("randomsted")
end)


Citizen.CreateThread(function()
  while true do
    Citizen.Wait(1) 
    local player = GetPlayerPed(-1)
    local coord = GetEntityCoords(player)
    if xcoord ~= nil and ycoord ~= nil and zcoord ~= nil and xcoord ~= 0 and ycoord ~= 0 and zcoord ~= 0 then
      if GetDistanceBetweenCoords(xcoord,ycoord,zcoord, coord.x, coord.y, coord.z) < 2.0 then
        if spawn == true then 
          if(IsControlJustReleased(1, 51))then 
            openGui()
            FreezeEntityPosition(lPed, true)
          end
        end
      end
    end
  end
end)

RegisterNetEvent("bmz_end:drug")
AddEventHandler("bmz_end:drug", function()
    spawn = false
    igang = false
    DeletePed(spawnped)
end)

RegisterNetEvent("bmz_accept:Kokain")
AddEventHandler("bmz_accept:Kokain", function()
    local player = GetPlayerPed(-1)
    local coord = GetEntityCoords(player)
    closeGui()
    exports['pn_progressbar']:startUI(6000, "Skriver kordinater ned.")
    TaskStartScenarioInPlace(GetPlayerPed(-1), "CODE_HUMAN_MEDIC_TIME_OF_DEATH", 0,false)
    Citizen.Wait(3000)
    ClearPedTasks(GetPlayerPed(-1))
    Citizen.Wait(3000)
    levering = true
    SetNewWaypoint(1045.5339355469,-2495.0595703125,28.493679046631)
    TriggerEvent("mythic_notify:client:SendAlert",{text = "Du har modtaget en GPS, Tjek kortet",type = "error",timeout = (10000),layout = "centerRight",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
end)

RegisterNetEvent("bmz_accept:Heroin")
AddEventHandler("bmz_accept:Heroin", function()
  local player = GetPlayerPed(-1)
  local coord = GetEntityCoords(player)
  closeGui()
  exports['pn_progressbar']:startUI(6000, "Skriver kordinater ned.")
  TaskStartScenarioInPlace(GetPlayerPed(-1), "CODE_HUMAN_MEDIC_TIME_OF_DEATH", 0,false)
  Citizen.Wait(3000)
  ClearPedTasks(GetPlayerPed(-1))
  Citizen.Wait(3000)
  levering = true
  SetNewWaypoint(817.78784179688,-490.13983154297,30.537481307983)
  TriggerEvent("mythic_notify:client:SendAlert",{text = "Du har modtaget en GPS, Tjek kortet",type = "error",timeout = (10000),layout = "centerRight",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
end)

RegisterNetEvent("bmz_accept:Skunk")
AddEventHandler("bmz_accept:Skunk", function()
  local player = GetPlayerPed(-1)
  local coord = GetEntityCoords(player)
  closeGui()
  exports['pn_progressbar']:startUI(6000, "Skriver kordinater ned.")
  TaskStartScenarioInPlace(GetPlayerPed(-1), "CODE_HUMAN_MEDIC_TIME_OF_DEATH", 0,false)
  Citizen.Wait(3000)
  ClearPedTasks(GetPlayerPed(-1))
  Citizen.Wait(3000)
  levering = true
  SetNewWaypoint(3333.0686035156,5159.337890625,18.303115844727)
  TriggerEvent("mythic_notify:client:SendAlert",{text = "Du har modtaget en GPS, Tjek kortet",type = "error",timeout = (10000),layout = "centerRight",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
end)

RegisterNetEvent("bmz_accept:Meth")
AddEventHandler("bmz_accept:Meth", function()
  local player = GetPlayerPed(-1)
  local coord = GetEntityCoords(player)
  closeGui()
  exports['pn_progressbar']:startUI(6000, "Skriver kordinater ned.")
  TaskStartScenarioInPlace(GetPlayerPed(-1), "CODE_HUMAN_MEDIC_TIME_OF_DEATH", 0,false)
  Citizen.Wait(3000)
  ClearPedTasks(GetPlayerPed(-1))
  Citizen.Wait(3000)
  levering = true
  SetNewWaypoint(1729.7542724609,4774.1069335938,41.827404022217)
  TriggerEvent("mythic_notify:client:SendAlert",{text = "Du har modtaget en GPS, Tjek kortet",type = "error",timeout = (10000),layout = "centerRight",queue = "global",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"}})
end)

Citizen.CreateThread(function ()
  while true do
    Citizen.Wait(1)
    local ped = PlayerPedId("a_m_m_soucent_04")
      if igang == true then
        if levering == true then
          if GetDistanceBetweenCoords(GetEntityCoords(ped),1045.7712402344,-2491.5544433594,30.274583816528, true) < 10 then
            DrawMarker(27,1045.7712402344,-2491.5544433594,28.574583816528-0.9,0,0,0,0,0,Rotation,3.001,3.0001,0.5001,255,0,0,200,0,0,0,true)
            if GetDistanceBetweenCoords(GetEntityCoords(ped),1045.7712402344,-2491.5544433594,30.274583816528, true) <= 5 then
              DrawText3Ds(1045.8258056641,-2491.697265625,28.874583816528, "~r~[E]~w~ For at aflevere kassen ")
              if IsControlJustReleased(1, 51) then
                exports['pn_progressbar']:startUI(5000, "Afleverer kassen.")
                TaskStartScenarioInPlace(PlayerPedId(), "PROP_HUMAN_BUM_BIN", 0, false)
                Citizen.Wait(4000)
                Stykke5 = CreateObject(250374685,1045.8513183594,-2491.5361328125,27.510339736938,true,false,false)
                Citizen.Wait(2000)
                TriggerServerEvent("bmz_drugbox:Betal1")
                TriggerServerEvent("bmz_drugbox:twitter")
                ClearPedTasks(GetPlayerPed(-1))
                DeleteObject(Stykke)
                DeleteObject(Stykke3)
                Citizen.Wait(20000)
                DeleteObject(Stykke5)
                levering = false
              end
            end
          elseif GetDistanceBetweenCoords(GetEntityCoords(ped),817.78784179688,-490.13983154297,30.537481307983, true) < 10 then
            DrawMarker(27,817.78784179688,-490.13983154297,30.537481307983-0.9,0,0,0,0,0,Rotation,3.001,3.0001,0.5001,255,0,0,200,0,0,0,true)
            if GetDistanceBetweenCoords(GetEntityCoords(ped),817.78784179688,-490.13983154297,30.537481307983, true) <= 5 then
              DrawText3Ds(817.78784179688,-490.13983154297,30.537481307983, "~r~[E]~w~ For at aflevere kassen ")
              if IsControlJustReleased(1, 51) then
                exports['pn_progressbar']:startUI(5000, "Afleverer kassen.")
                TaskStartScenarioInPlace(PlayerPedId(), "PROP_HUMAN_BUM_BIN", 0, false)
                Citizen.Wait(4000)
                Stykke5 = CreateObject(250374685,817.78784179688,-490.13983154297,29.537481307983,true,false,false)
                Citizen.Wait(2000)
                TriggerServerEvent("bmz_drugbox:Betal2")
                TriggerServerEvent("bmz_drugbox:twitter")
                ClearPedTasks(GetPlayerPed(-1))
                DeleteObject(Stykke)
                DeleteObject(Stykke3)
                Citizen.Wait(20000)
                DeleteObject(Stykke5)
                levering = false
              end
            end
          elseif GetDistanceBetweenCoords(GetEntityCoords(ped),3333.0686035156,5159.337890625,18.303115844727, true) < 10 then
            DrawMarker(27,3333.0686035156,5159.337890625,18.303115844727-0.9,0,0,0,0,0,Rotation,3.001,3.0001,0.5001,255,0,0,200,0,0,0,true)
            if GetDistanceBetweenCoords(GetEntityCoords(ped),3333.0686035156,5159.337890625,18.303115844727, true) <= 5 then
              DrawText3Ds(3333.0686035156,5159.337890625,18.303115844727, "~r~[E]~w~ For at aflevere kassen ")
              if IsControlJustReleased(1, 51) then
                exports['pn_progressbar']:startUI(5000, "Afleverer kassen.")
                TaskStartScenarioInPlace(PlayerPedId(), "PROP_HUMAN_BUM_BIN", 0, false)
                Citizen.Wait(4000)
                Stykke5 = CreateObject(250374685,3333.0686035156,5159.337890625,17.253115844727,true,false,false)
                Citizen.Wait(2000)
                TriggerServerEvent("bmz_drugbox:Betal3")
                TriggerServerEvent("bmz_drugbox:twitter")
                ClearPedTasks(GetPlayerPed(-1))
                DeleteObject(Stykke)
                DeleteObject(Stykke3)
                Citizen.Wait(20000)
                DeleteObject(Stykke5)
                levering = false
              end
            end
          elseif GetDistanceBetweenCoords(GetEntityCoords(ped),1729.7542724609,4774.1069335938,41.827404022217, true) < 10 then
            DrawMarker(27,1729.7542724609,4774.1069335938,41.827404022217-0.9,0,0,0,0,0,Rotation,3.001,3.0001,0.5001,255,0,0,200,0,0,0,true)
            if GetDistanceBetweenCoords(GetEntityCoords(ped),1729.7542724609,4774.1069335938,41.827404022217, true) <= 5 then
              DrawText3Ds(1729.7542724609,4774.1069335938,41.827404022217, "~r~[E]~w~ For at aflevere kassen ")
              if IsControlJustReleased(1, 51) then
                exports['pn_progressbar']:startUI(5000, "Afleverer kassen.")
                TaskStartScenarioInPlace(PlayerPedId(), "PROP_HUMAN_BUM_BIN", 0, false)
                Citizen.Wait(4000)
                Stykke5 = CreateObject(250374685,1729.7542724609,4774.1069335938,40.827404022217,true,false,false)
                Citizen.Wait(2000)
                TriggerServerEvent("bmz_drugbox:Betal4")
                TriggerServerEvent("bmz_drugbox:twitter")
                ClearPedTasks(GetPlayerPed(-1))
                DeleteObject(Stykke)
                DeleteObject(Stykke3)
                Citizen.Wait(20000)
                DeleteObject(Stykke5)
                levering = false
              end
            end
          end
        end
      end
  end
end)


---Må ikke fjernes---

function DrawText3Ds(x,y,z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
  end
