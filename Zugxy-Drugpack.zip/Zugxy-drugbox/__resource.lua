--PHILIP'S FILER       ALLE RETTIGHEDER      KAN KØBES HER: https://discord.gg/cWyYnB2nAB 
resource_manifest_version "44febabe-d386-4d18-afbe-5e627f4af937"

ui_page "html/ui.html"
dependency "mysql-async"


files {
	"html/ui.html",
	"html/styles.css",
	"html/scripts.js",

}

client_scripts {
    'lib/Proxy.lua',
    'lib/Tunnel.lua',
    'client.lua',
    'config.lua',
    "cfg.lua"
}

server_scripts {
	"@mysql-async/lib/MySQL.lua",
    '@vrp/lib/utils.lua',
    'config.lua',
    'server.lua',
    "cfg.lua"
}


