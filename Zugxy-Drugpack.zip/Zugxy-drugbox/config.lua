--PHILIP'S FILER       ALLE RETTIGHEDER      KAN KØBES HER: https://discord.gg/cWyYnB2nAB 
cfg = {}

cfg.steder = { -- steder
    [1] = {
        xyz = { ['x'] = -77.980026245117, ['y'] = -1391.1135253906, ['z'] = 29.320737838745-1, ['heading'] = 271.19 },  -- -77.980026245117,-1391.1135253906,29.320737838745
        hint = "Er der nogen der husker, dengang man kunne lave sit eget sne, tæt på stripklubben?"
    },
    [2] = {
        xyz = { ['x'] = 1920.1608886719, ['y'] = 589.80487060547, ['z'] = 176.36730957031-1, ['heading'] = 330.60 },  -- 1920.1608886719,589.80487060547,176.36730957031
        hint = "En sø? I midten af bjerge? Og hvad sker der lige for de her store rør?"
    },
    [3] = {
        xyz = { ['x'] = 9.9876823425293, ['y'] = -667.23699951172, ['z'] = 33.449214935303-1, ['heading'] = 161.0 }, -- 9.9876823425293,-667.23699951172,33.449214935303
        hint = "Hvorfor har Union Depository, et kontor i en parkeringskælder?"
    },
    [4] = {
      xyz = { ['x'] = 3600.9431152344, ['y'] = 3660.9931640625, ['z'] = 32.871803283691, ['heading'] = 75.00 }, -- 3600.9431152344,3660.9931640625,32.871803283691
      hint = "Det er svært, at finde rundt i alle de kemiske processer, som de bruger på Labs. Synes i ikke?"
  },
  [5] = {
    xyz = { ['x'] = -1175.3803710938, ['y'] = -686.60473632813, ['z'] = 40.357574462891-1, ['heading'] = 75.00 }, -- -1175.3803710938,-686.60473632813,40.357574462891
    hint = "Et parkeringshus? Det ligner Tivoli med alt det farvede lys!"
    }
}

