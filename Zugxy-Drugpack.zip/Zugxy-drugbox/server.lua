--PHILIP'S FILER       ALLE RETTIGHEDER      KAN KØBES HER: https://discord.gg/cWyYnB2nAB 
local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

local logs_til_discord = GetConvar("logs_til_discord", "Nej")

vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP","SCRIPTNAVNHER")



function twitter_addMessage (user_id, name, message, time)
  MySQL.Async.execute("INSERT INTO `phone_twitter`(`userid`, `name`, `message`, `time`) VALUES (@userid, @name, @message, @time)", {userid = user_id, name = name, message = message, time = time}, function(affected)
    TriggerEvent("gcphone:addtweet",name,message,time)
    TriggerClientEvent('gcPhone:twitter_receive', -1, {userid=user_id,name=name,message=message,time=time})
  end)
end


RegisterServerEvent("bmz_drugbox:button1")
AddEventHandler("bmz_drugbox:button1", function()
  local source = source
  local user_id = vRP.getUserId({source})
  if vRP.getInventoryItemAmount({user_id,"kokainbox"}) > 0 then
    TriggerClientEvent("bmz_accept:Kokain",source)
    if logs_til_discord == "Ja" or logs_til_discord == "ja" then
      PerformHttpRequest('https://discord.com/api/webhooks/787989113403211816/3qnDq105OZ97lQfAJsMMHpEveebAy9-sp8MPMXQRpbZM_3-93b5JvQIO5_Ze90dkwxOF', function(err, text, headers) end, 'POST', json.encode({username = "Drugbox", content = "```Brugeren "..user_id.." solgte en kokain drugbox```"}), { ['Content-Type'] = 'application/json' })
    end
  else
    TriggerClientEvent("mythic_notify:client:SendAlert", source,{text = "Du har ikke råd.", type = "error", queue = "global", timeout = 4000, layout = "centerLeft",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
  end
end)

RegisterServerEvent("bmz_drugbox:button2")
AddEventHandler("bmz_drugbox:button2", function()
  local source = source
  local user_id = vRP.getUserId({source})
  if vRP.getInventoryItemAmount({user_id,"heroinbox"}) > 0 then
    TriggerClientEvent("bmz_accept:Heroin",source)
    if logs_til_discord == "Ja" or logs_til_discord == "ja" then
      PerformHttpRequest('https://discord.com/api/webhooks/787989113403211816/3qnDq105OZ97lQfAJsMMHpEveebAy9-sp8MPMXQRpbZM_3-93b5JvQIO5_Ze90dkwxOF', function(err, text, headers) end, 'POST', json.encode({username = "Drugbox", content = "```Brugeren "..user_id.." solgte en heroin drugbox```"}), { ['Content-Type'] = 'application/json' })
    end
  else
    TriggerClientEvent("mythic_notify:client:SendAlert", source,{text = "Du har ikke råd.", type = "error", queue = "global", timeout = 4000, layout = "centerLeft",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
  end
end)

RegisterServerEvent("bmz_drugbox:button3")
AddEventHandler("bmz_drugbox:button3", function()
  local source = source
  local user_id = vRP.getUserId({source})
  if vRP.getInventoryItemAmount({user_id,"skunkbox"}) > 0 then
    TriggerClientEvent("bmz_accept:Skunk",source)
    if logs_til_discord == "Ja" or logs_til_discord == "ja" then
      PerformHttpRequest('https://discord.com/api/webhooks/787989113403211816/3qnDq105OZ97lQfAJsMMHpEveebAy9-sp8MPMXQRpbZM_3-93b5JvQIO5_Ze90dkwxOF', function(err, text, headers) end, 'POST', json.encode({username = "Drugbox", content = "```Brugeren "..user_id.." solgte en skunk drugbox```"}), { ['Content-Type'] = 'application/json' })
    end
  else
    TriggerClientEvent("mythic_notify:client:SendAlert", source,{text = "Du har ikke råd.", type = "error", queue = "global", timeout = 4000, layout = "centerLeft",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
  end
end)

RegisterServerEvent("bmz_drugbox:button4")
AddEventHandler("bmz_drugbox:button4", function()
  local source = source
  local user_id = vRP.getUserId({source})
  if vRP.getInventoryItemAmount({user_id,"methbox"}) > 0 then
    TriggerClientEvent("bmz_accept:Meth",source)
    if logs_til_discord == "Ja" or logs_til_discord == "ja" then
      PerformHttpRequest('https://discord.com/api/webhooks/787989113403211816/3qnDq105OZ97lQfAJsMMHpEveebAy9-sp8MPMXQRpbZM_3-93b5JvQIO5_Ze90dkwxOF', function(err, text, headers) end, 'POST', json.encode({username = "Drugbox", content = "```Brugeren "..user_id.." solgte en meth drugbox```"}), { ['Content-Type'] = 'application/json' })
    end
  else
    TriggerClientEvent("mythic_notify:client:SendAlert", source,{text = "Du har ikke råd.", type = "error", queue = "global", timeout = 4000, layout = "centerLeft",animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},killer = true})
  end
end)

RegisterServerEvent("bmz_drugbox:Betal1")
AddEventHandler("bmz_drugbox:Betal1", function()
  local source = source
  local user_id = vRP.getUserId({source})
  if vRP.tryGetInventoryItem({user_id,"kokainbox",1,true}) then
    vRP.giveInventoryItem({user_id,"dirty_money",2300000,true})
    TriggerClientEvent("bmz_end:drug", -1)
  end
end)

RegisterServerEvent("bmz_drugbox:Betal2")
AddEventHandler("bmz_drugbox:Betal2", function()
  local source = source
  local user_id = vRP.getUserId({source})
  if vRP.tryGetInventoryItem({user_id,"heroinbox",1,true}) then
    vRP.giveInventoryItem({user_id,"dirty_money",4000000,true})
    TriggerClientEvent("bmz_end:drug", -1)
  end
end)

RegisterServerEvent("bmz_drugbox:Betal3")
AddEventHandler("bmz_drugbox:Betal3", function()
  local source = source
  local user_id = vRP.getUserId({source})
  if vRP.tryGetInventoryItem({user_id,"skunkbox",1,true}) then
    vRP.giveInventoryItem({user_id,"dirty_money",2900000,true})
    TriggerClientEvent("bmz_end:drug", -1)
  end
end)

RegisterServerEvent("bmz_drugbox:Betal4")
AddEventHandler("bmz_drugbox:Betal4", function()
  local source = source
  local user_id = vRP.getUserId({source})
  if vRP.tryGetInventoryItem({user_id,"methbox",1,true}) then
    vRP.giveInventoryItem({user_id,"dirty_money",2300000,true})
    TriggerClientEvent("bmz_end:drug", -1)
  end
end)

RegisterNetEvent("spawntrue")
AddEventHandler("spawntrue", function()
    TriggerClientEvent("bmz:spawntrue", -1)
end)

RegisterServerEvent("bmz_updateS:coords")
AddEventHandler("bmz_updateS:coords", function(x, y, z)
  TriggerClientEvent("bmz_updateC:coords", -1, x, y, z)
end)

RegisterServerEvent('bmz_drugbox:sendtwitter')
AddEventHandler('bmz_drugbox:sendtwitter', function(random)
local user_id = 1
local name = "Joaquín Guzmán Loera"
local time = os.date('%H:%M - %d/%m/%y', os.time()) --"00:00 - 00/00/00"
	if random == 1 then
		chatmessage = cfg.steder[1].hint
	elseif random == 2 then
		chatmessage = cfg.steder[2].hint
	elseif random == 3 then
		chatmessage = cfg.steder[3].hint
	elseif random == 4 then
		chatmessage = cfg.steder[4].hint
	elseif random == 5 then
		chatmessage = cfg.steder[5].hint
  end
TriggerClientEvent('chat:addMessage', -1, {
  color = {255, 255, 255},
  multiline = true,
  args = {"["..os.date("%H")..":"..os.date("%M").."] ‎‎‎ ‎🐤 ^4Twitter ^7| @JoaquínGuzmánLoera", chatmessage }
})
end)


RegisterServerEvent('bmz_drugbox:twitter')
AddEventHandler('bmz_drugbox:twitter', function(banknavn)
Citizen.Wait(1000)
local user_id = 1
local name = "Joaquín Guzmán Loera"
local time = os.date('%H:%M - %d/%m/%y', os.time()) --"00:00 - 00/00/00"
local chatmessage = "Gracias por ahora - Tak for nu!"
TriggerClientEvent('chat:addMessage', -1, {
  color = {255, 255, 255},
  multiline = true,
  args = {"["..os.date("%H")..":"..os.date("%M").."] ‎‎‎ ‎🐤 ^4Twitter ^7| @JoaquínGuzmánLoera", chatmessage }
})
end)